# https://www.codingforentrepreneurs.com/blog/opencv-python-extract-faces-rest-api-flask
import numpy as np
import tensorflow as tf
import cv2
import time
from PIL import Image
from flask import Flask, request, jsonify
import io
import os
import base64

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
app = Flask(__name__)


class DetectorAPI:
    def __init__(self, path_to_ckpt):
        self.path_to_ckpt = path_to_ckpt

        self.detection_graph = tf.Graph()
        with self.detection_graph.as_default():
            od_graph_def = tf.GraphDef()
            with tf.gfile.GFile(self.path_to_ckpt, 'rb') as fid:
                serialized_graph = fid.read()
                od_graph_def.ParseFromString(serialized_graph)
                tf.import_graph_def(od_graph_def, name='')

        self.default_graph = self.detection_graph.as_default()
        self.sess = tf.Session(graph=self.detection_graph)

        # Definite input and output Tensors for detection_graph
        self.image_tensor = self.detection_graph.get_tensor_by_name(
            'image_tensor:0')
        # Each box represents a part of the image where a particular object was detected.
        self.detection_boxes = self.detection_graph.get_tensor_by_name(
            'detection_boxes:0')
        # Each score represent how level of confidence for each of the objects.
        # Score is shown on the result image, together with the class label.
        self.detection_scores = self.detection_graph.get_tensor_by_name(
            'detection_scores:0')
        self.detection_classes = self.detection_graph.get_tensor_by_name(
            'detection_classes:0')
        self.num_detections = self.detection_graph.get_tensor_by_name(
            'num_detections:0')

    def processFrame(self, image):
        # Expand dimensions since the trained_model expects images to have shape: [1, None, None, 3]
        image_np_expanded = np.expand_dims(image, axis=0)
        # Actual detection.
        start_time = time.time()
        (boxes, scores, classes, num) = self.sess.run(
            [self.detection_boxes, self.detection_scores,
                self.detection_classes, self.num_detections],
            feed_dict={self.image_tensor: image_np_expanded})
        end_time = time.time()

        print("Elapsed Time:", end_time-start_time)

        im_height, im_width, _ = image.shape
        boxes_list = [None for i in range(boxes.shape[1])]
        for i in range(boxes.shape[1]):
            boxes_list[i] = (int(boxes[0, i, 0] * im_height),
                             int(boxes[0, i, 1]*im_width),
                             int(boxes[0, i, 2] * im_height),
                             int(boxes[0, i, 3]*im_width))

        return boxes_list, scores[0].tolist(), [int(x) for x in classes[0].tolist()], int(num[0])

    def close(self):
        self.sess.close()
        self.default_graph.close()


def load_model(model_path):
    global odapi
    global graph
    odapi = DetectorAPI(path_to_ckpt=model_path)
    graph = tf.get_default_graph()


def image_from_buffer(file_buffer):
    '''
    If we don't save the file locally and just want to open
    a POST'd file. This is what we use.
    '''
    bytes_as_np_array = np.frombuffer(file_buffer.read(), dtype=np.uint8)
    flag = 1
    frame = cv2.imdecode(bytes_as_np_array, flag)
    return frame


@app.route('/predict', methods=['POST'])
def predict():
    data = {'success': False}
    print('request')
    if request.method == 'POST':
        if request.files.get('image'):
            img = request.files['image']
            im = image_from_buffer(img)
            with graph.as_default():
                boxes, scores, classes, num = odapi.processFrame(im)
            threshold = 0.5

            data['predictions'] = []
            counts = 0
            for i in range(len(boxes)):
                if classes[i] == 1 and scores[i] >= threshold:
                    data_dict = {
                        "Class": classes[i],
                        "Box": boxes[i],
                        "Score": scores[i]
                    }
                    data['predictions'].append(data_dict)
                    counts += 1
            data["counts"] = counts
            data['success'] = True

    return jsonify(data)


# 當啟動 server 時先去預先 load model 每次 request 都要重新 load 造成效率低下且資源浪費
if __name__ == '__main__':
    load_model('frozen_inference_graph.pb')
    app.run()
