# https://www.codingforentrepreneurs.com/blog/opencv-python-extract-faces-rest-api-flask
import numpy as np
import tensorflow as tf
import cv2
import time
from PIL import Image
from flask import Flask, request, jsonify
import io
import os
import base64

os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
app = Flask(__name__)


class MTCNN:
    def __init__(self, model_path, min_size=40, factor=0.709, thresholds=[0.6, 0.7, 0.7]):
        self.min_size = min_size
        self.factor = factor
        self.thresholds = thresholds

        graph = tf.Graph()
        with graph.as_default():
            with open(model_path, 'rb') as f:
                graph_def = tf.GraphDef.FromString(f.read())
                tf.import_graph_def(graph_def, name='')
        self.graph = graph
        config = tf.ConfigProto(
            allow_soft_placement=True,
            intra_op_parallelism_threads=4,
            inter_op_parallelism_threads=4)
        config.gpu_options.allow_growth = True
        self.sess = tf.Session(graph=graph, config=config)

    def detect(self, img):
        feeds = {
            self.graph.get_operation_by_name('input').outputs[0]: img,
            self.graph.get_operation_by_name('min_size').outputs[0]: self.min_size,
            self.graph.get_operation_by_name('thresholds').outputs[0]: self.thresholds,
            self.graph.get_operation_by_name('factor').outputs[0]: self.factor
        }
        fetches = [self.graph.get_operation_by_name('prob').outputs[0],
                   self.graph.get_operation_by_name('landmarks').outputs[0],
                   self.graph.get_operation_by_name('box').outputs[0]]
        prob, landmarks, box = self.sess.run(fetches, feeds)
        return box, prob, landmarks


def load_model(model_path):
    global mtcnn
    global graph
    mtcnn = MTCNN(model_path)
    graph = tf.get_default_graph()


def image_from_buffer(file_buffer):
    '''
    If we don't save the file locally and just want to open
    a POST'd file. This is what we use.
    '''
    bytes_as_np_array = np.frombuffer(file_buffer.read(), dtype=np.uint8)
    flag = 1
    frame = cv2.imdecode(bytes_as_np_array, flag)
    return frame


@app.route('/predict', methods=['POST'])
def predict():
    data = {'success': False}
    print('request')
    if request.method == 'POST':
        if request.files.get('image'):
            img = request.files['image']
            im = image_from_buffer(img)
            with graph.as_default():
                boxes, scores, _ = mtcnn.detect(im)

            threshold = 0.5

            data['predictions'] = []
            counts = 0
            for i in range(len(boxes)):
                if scores[i] >= threshold:
                    box = boxes[i].tolist()
                    box = [int(i) for i in box]
                    data_dict = {
                        "Box": box,
                        "Score": float(round(scores[i], 2))
                    }
                    data['predictions'].append(data_dict)
                    counts += 1
            data["counts"] = counts
            data['success'] = True
            print(data)
    return jsonify(data)


# 當啟動 server 時先去預先 load model 每次 request 都要重新 load 造成效率低下且資源浪費
if __name__ == '__main__':
    load_model('mtcnn.pb')
    app.run()
