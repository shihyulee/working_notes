# https://github.com/spmallick/learnopencv/tree/master/WeChat-QRCode-Scanner-OpenCV
import cv2
import sys
import numpy as np

def displayBboxWeChat(im, bbox):
	if bbox is not None:
		bbox = [bbox[0].astype(int)]
		n = len(bbox[0])
		for i in range(n):
			cv2.line(im, tuple(bbox[0][i]), tuple(bbox[0][(i+1) % n]), green, 3)


def wechatQR(im, detector):
	# Detect and decode.
	res, points = detector.detectAndDecode(im)
	if len(res) > 0:
		print('QR Data: ', res)
		cv2.putText(im, 'Output: {}'.format(res[0]), (20, im.shape[0] - 25), font, fontScale, green, 2)
		displayBboxWeChat(im, points)
	else:
		print('QRCode not detected')
		cv2.putText(im, 'Output: Not Detected', (20, im.shape[0] - 25), font, fontScale, red, 2)
	return im


#==============================================CONSTANTS================================================#
# Color.
red = (0,0,255)
green = (0,255,0)
blue = (255,0,0)
yellow = (0,255,255)
# Font.
font = cv2.FONT_HERSHEY_SIMPLEX
fontScale = 0.8

#============================================INITIALIZATIONS==============================================#
# Instantiate WeChat QR Code detector.
weChatDetector = cv2.wechat_qrcode_WeChatQRCode("model/detect.prototxt",
	"model/detect.caffemodel",
	"model/sr.prototxt",
	"model/sr.caffemodel")
#=========================================================================================================#


if __name__== '__main__':

	# if len(sys.argv)>1:
	# 	vidCapture = cv2.VideoCapture(sys.argv[1])
	# else:
	# 	vidCapture = cv2.VideoCapture(0)
	vidCapture = cv2.VideoCapture(0)
	vidCapture.set(cv2.CAP_PROP_AUTOFOCUS, 1)

	while (vidCapture.isOpened()):
		ret, frame = vidCapture.read()
		if not ret:
			print('Error reading frames.')
			break
		img = frame.copy()
		# Call WeChat QR Code scanner.
		result = wechatQR(img.copy(), weChatDetector)
		cv2.imshow('Frame',result)
		key = cv2.waitKey(1)
		if key == ord('q'):
			break

	vidCapture.release()
	cv2.destroyAllWindows()
